
package com.mycompany.login;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testGetTaskName() {
        Task task = new Task();
        task.setTaskName("Test Task");
        assertEquals("Test Task", task.getTaskName());
    }

    @Test
    public void testSetTaskName() {
        Task task = new Task();
        task.setTaskName("Test Task");
        assertEquals("Test Task", task.getTaskName());
    }

    @Test
    public void testGetTaskNumber() {
        Task task = new Task();
        task.setTaskNumber(1);
        assertEquals(1, task.getTaskNumber());
    }

    @Test
    public void testSetTaskNumber() {
        Task task = new Task();
        task.setTaskNumber(1);
        assertEquals(1, task.getTaskNumber());
    }

    @Test
    public void testGetTaskDescription() {
        Task task = new Task();
        task.setTaskDescription("Description");
        assertEquals("Description", task.getTaskDescription());
    }

    @Test
    public void testSetTaskDescription() {
        Task task = new Task();
        task.setTaskDescription("Description");
        assertEquals("Description", task.getTaskDescription());
    }

    @Test
    public void testGetTaskStatus() {
        Task task = new Task();
        task.setTaskStatus("In Progress");
        assertEquals("In Progress", task.getTaskStatus());
    }

    @Test
    public void testSetTaskStatus() {
        Task task = new Task();
        task.setTaskStatus("In Progress");
        assertEquals("In Progress", task.getTaskStatus());
    }

    @Test
    public void testCheckTaskDescriptionTASK1() {
        Task task = new Task();
        String actual = "Create Login to authenticate users";
        String expected = "Task successfully captured";
        assertEquals(expected, task.checkTaskDescription(actual));
    }

    @Test
    public void testCheckTaskDescriptionTASK2() {
        Task task = new Task();
        String actual = "Create Add Task feature to add task users.......";
        String expected = "Please enter a task description of less than 50 characters";
        assertEquals(expected, task.checkTaskDescription(actual));
    }

    @Test
    public void testCreateTaskIDTASK1() {
        Task task = new Task();
        String expected = "LO:0:ROB";
        assertEquals(expected, task.createTaskID("Login Feature", 0, "Robyn Marrison"));
    }

    @Test
    public void testCreateTaskIDTASK2() {
        Task task = new Task();
        String expected = "AD:1:MIK";
        assertEquals(expected, task.createTaskID("Add Task Feature", 1, "Mike Smith"));
    }
}
