package com.mycompany.login;

public class Task {

    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskStatus;
    private int total;

    public Task() {
        this.total = 0;
    }

    public String getTaskName() {
        return this.taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public int getTaskNumber() {
        return this.taskNumber;
    }

    public void setTaskNumber(int taskNumber) {
        this.taskNumber = taskNumber;
    }

    public String getTaskDescription() {
        return this.taskDescription;
    }

    public void setTaskDescription(String taskDescription) {
        this.taskDescription = taskDescription;
    }

    public String getDeveloperDetails() {
        return this.developerDetails;
    }

    public void setDeveloperDetails(String developerDetails) {
        this.developerDetails = developerDetails;
    }

    public int getTaskDuration() {
        return this.taskDuration;
    }

    public void setTaskDuration(int taskDuration) {
        this.taskDuration = taskDuration;
    }

    public String getTaskStatus() {
        return this.taskStatus;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }

    public int getTotal() {
        return this.total;
    }

    public String checkTaskDescription(String taskDescription) {
        int descriptionLength = taskDescription.length();
        if (descriptionLength <= 50) {
            this.setTaskDescription(taskDescription);
            return "Task successfully captured";
        } else {
            return "Please enter a task description of less than 50 characters";
        }
    }

    public String createTaskID(String taskName, int taskNumber, String developer) {
        String[] names = developer.split(" ");
        if (names.length < 2) {
            return "Invalid developer name";
        }
        String firstName = names[0];
        String taskId = taskName.substring(0, 2).toUpperCase() + ":" + taskNumber + ":" + firstName.substring(0, 3).toUpperCase();
        return taskId;
    }

    public int returnTotalHours(int numTask, int taskDuration) {
        this.total = numTask * taskDuration;
        return this.total;
    }

    public String printTaskDetails(String taskID) {
        return "Task Details:\n" +
                "Task status: " + this.taskStatus + "\n" +
                "Developer Details: " + this.developerDetails + "\n" +
                "Task Number: " + this.taskNumber + "\n" +
                "Task Name: " + this.taskName + "\n" +
                "Task Description: " + this.taskDescription + "\n" +
                "Task ID: " + taskID + "\n" +
                "Task Duration: " + this.taskDuration;
    }

    public void display() {
        javax.swing.JOptionPane.showMessageDialog(null, "Total hours for all tasks: " + this.total);
    }
}
