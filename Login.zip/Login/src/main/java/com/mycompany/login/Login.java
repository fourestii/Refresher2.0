package com.mycompany.login;

import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Arrays;

public class Login {

    private String firstName;
    private String surname;
    private String userName;
    private String password;
    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskStatus;
    private int total;

    public static void main(String[] args) {
        Login login = new Login();
        login.getUserInput();
        login.checkUserInput();

        JOptionPane.showMessageDialog(null, login.returnLoginStatus());

        
        login.getTaskInput();
        login.displayTaskDetails();
        JOptionPane.showMessageDialog(null, "Total hours for all tasks: " + login.returnTotalHours(1, login.taskDuration));

        // Additional task-related operations
        ArrayList<String> developer = new ArrayList<>(Arrays.asList("Mike Smith", "Edward Harrison", "Samantha Paulson", "Glenda Oberholzer"));
        ArrayList<String> taskName = new ArrayList<>(Arrays.asList("Create Login", "Create Add Feature", "Create Report", "Add Arrays"));
        ArrayList<String> taskStatus = new ArrayList<>(Arrays.asList("ToDo", "Doing", "Done", "ToDo"));
        ArrayList<Integer> taskID = new ArrayList<>(Arrays.asList(001, 002, 003, 004));
        ArrayList<Integer> duration = new ArrayList<>(Arrays.asList(5, 8, 2, 11));

        // Task with status "Done"
        JOptionPane.showMessageDialog(null, "Developer, Task Name and Task Duration with the status of Done:\n"
                                        + developer.get(2) + ": " + taskName.get(2) + ", Duration: " + duration.get(2));

        
        int maxDurationIndex = 0;
        int maxDuration = duration.get(0);
        for (int i = 1; i < duration.size(); i++) {
            if (duration.get(i) > maxDuration) {
                maxDuration = duration.get(i);
                maxDurationIndex = i;
            }
        }
        JOptionPane.showMessageDialog(null, "Developer and duration of the Task with longest duration:\n"
                                        + developer.get(maxDurationIndex) + ", Duration: " + duration.get(maxDurationIndex));

        // Report of all captured tasks
        StringBuilder report = new StringBuilder("Report of all captured tasks:\n");
        for (String task : taskName) {
            report.append(task).append("\n");
        }
        JOptionPane.showMessageDialog(null, report.toString());

        
        taskName.remove("Item");

       
        StringBuilder tasksByDevelopers = new StringBuilder();
        boolean developerFound = false;
        for (int i = 0; i < developer.size(); i++) {
            if (developer.contains("Mike Smith") || developer.contains("Edward Harrison") || developer.contains("Samantha Paulson") || developer.contains("Glenda Oberholzer")) {
                tasksByDevelopers.append("Developer: ").append(developer.get(i)).append(", Task: ").append(taskName.get(i)).append(", Status: ").append(taskStatus.get(i)).append("\n");
                developerFound = true;
            }
        }
        if (developerFound) {
            JOptionPane.showMessageDialog(null, "Tasks assigned to developers:\n" + tasksByDevelopers.toString());
        } else {
            JOptionPane.showMessageDialog(null, "Developer not found");
        }
    }

    private void getUserInput() {
        firstName = JOptionPane.showInputDialog("Please enter your first name");
        surname = JOptionPane.showInputDialog("Please enter your surname");
        userName = JOptionPane.showInputDialog("Please enter your userName");
        password = JOptionPane.showInputDialog("Please enter your password");
    }

    private boolean checkUserName() {
        return userName.contains("_") && userName.length() <= 5;
    }

    private boolean checkPasswordComplexity() {
        boolean length = password.length() >= 8;
        boolean number = false;
        boolean specialCharacter = false;
        boolean upperCase = false;

        for (char ch : password.toCharArray()) {
            if (Character.isDigit(ch)) number = true;
            if (Character.isUpperCase(ch)) upperCase = true;
            if (!Character.isLetterOrDigit(ch)) specialCharacter = true;
        }
        return length && number && specialCharacter && upperCase;
    }

    private void checkUserInput() {
        String nameMessage;
        if (checkUserName()) {
            nameMessage = "Username successfully captured";
        } else {
            nameMessage = "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length";
        }
        JOptionPane.showMessageDialog(null, nameMessage);

        if (checkPasswordComplexity()) {
            nameMessage = "Password successfully captured";
        } else {
            nameMessage = "Password is not correctly formatted, please ensure the password contains at least 8 characters, a capital letter, a number, and a special character.";
        }
        JOptionPane.showMessageDialog(null, nameMessage);
    }

    private boolean login1User() {
        String username2 = JOptionPane.showInputDialog("Enter the username you used to create an account");
        String password2 = JOptionPane.showInputDialog("Enter the password you used to create an account");

        return userName.equals(username2) && password.equals(password2);
    }

    private String returnLoginStatus() {
        if (login1User()) {
            return "Welcome " + firstName + " " + surname + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    private void getTaskInput() {
        taskName = JOptionPane.showInputDialog("Please enter the task name");
        taskNumber = Integer.parseInt(JOptionPane.showInputDialog("Please enter the task number"));
        taskDescription = JOptionPane.showInputDialog("Please enter the task description");
        developerDetails = JOptionPane.showInputDialog("Please enter the developer details");
        taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Please enter the task duration in hours"));
        taskStatus = JOptionPane.showInputDialog("Please enter the task status");
        checkTaskDescription(taskDescription);
    }

    private void checkTaskDescription(String taskDescription) {
        int descriptionLength = taskDescription.length();
        if (descriptionLength <= 50) {
            this.taskDescription = taskDescription;
            JOptionPane.showMessageDialog(null, "Task successfully captured");
        } else {
            JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
        }
    }

    private String createTaskID(String taskName, int taskNumber, String developer) {
        String[] names = developer.split(" ");
        if (names.length < 2) {
            return "Invalid developer name";
        }
        String firstName = names[0];
        return taskName.substring(0, 2).toUpperCase() + ":" + taskNumber + ":" + firstName.substring(0, 3).toUpperCase();
    }

    private int returnTotalHours(int numTask, int taskDuration) {
        this.total = numTask * taskDuration;
        return this.total;
    }

    private void displayTaskDetails() {
        String taskID = createTaskID(taskName, taskNumber, developerDetails);
        String taskDetails = "Task Details:\n" +
                "Task status: " + taskStatus + "\n" +
                "Developer Details: " + developerDetails + "\n" +
                "Task Number: " + taskNumber + "\n" +
                "Task Name: " + taskName + "\n" +
                "Task Description: " + taskDescription + "\n" +
                "Task ID: " + taskID + "\n" +
                "Task Duration: " + taskDuration;
        JOptionPane.showMessageDialog(null, taskDetails);
    }
}
